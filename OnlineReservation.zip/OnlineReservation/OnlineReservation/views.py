from django.shortcuts import render



def index(request):
	return render(request,"index.html")

def signup(request):
	return render(request,"signup.html")
def book(request):
	return render(request,"book.html")

def login(request):
	data = {}
	if request.session.has_key('user'):
		data['id'] = request.session['user']
		data['fname'] = request.session['fname']
		data['lname'] = request.session['lname']
		return render(request,"welcome.html",data)
	return render(request,"login.html")

def logout(request):
	if request.session.has_key('user'):
		del request.session['user']
		del request.session['fname']
		del request.session['lname']

	return render(request,"login.html")