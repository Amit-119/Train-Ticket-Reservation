from django.shortcuts import render
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from .models import Users

# Create your views here.
def index(request):
	return render(request,"index.html")

from django.core.files.storage import FileSystemStorage

def login(request):
	data = {}
	if request.session.has_key('user'):
		data['id'] = request.session['user']
		data['fname'] = request.session['fname']
		data['lname'] = request.session['lname']
		return render(request,"welcome.html",data)
	return render(request,"login.html")

def logout(request):
	if request.session.has_key('user'):
		del request.session['user']
		del request.session['fname']
		del request.session['lname']

	return render(request,"login.html")



def dologin(request):
	data={}

	if request.method =="POST":
		try:
			user = Users.objects.filter(email = request.POST['email']).values()[0]
			if check_password(request.POST['pass'],user['passw']):
				request.session['user'] = request.POST['email']
				request.session['fname'] = str(user['fname'])
				request.session['lname'] = str(user['lname'])
				request.session.set_expiry(300)
				data['fname'] = request.session['fname']
				data['lname'] = request.session['lname']
				data['id'] = request.session['user']

				return render(request,"welcome.html",data)

				
			else:
				msg = "Invalid password please retry  "
				msg +="<a href='/client/login'>Relogin</a>"
		except:
			msg  = "Users Not Registered  Please Register"
			msg	+= "</br><a href='/signup'>Click Here</a>"
		return HttpResponse("<h2>"+msg+"</h2>")
	return HttpResponse("<h1>Blank<h1>")




def book(request):
	return render(request,"book.html")

def doregister(request):
	if request.method == "POST":
		form = Users()
		try:
			data = Users.objects.get(email = request.POST['email'])
			msg  = "<center><h1 style='color:green;padding:200px;'>User Already\
			 Register Please <a href='/login'>Login</a></h1></center>"
		except:
			form.fname		= request.POST['fname']
			form.lname		= request.POST['lname']
			form.email 		= request.POST['email']
			form.passw 		= make_password(request.POST['pass'])
			form.mob   	= request.POST['mob']
			form.gen   		= request.POST['gen']
			form.save()
			msg	="<center><h1 style='color:green;padding:200px;'>Congratulations! \
			you are registered <br><a href='/login'>Login</a>&nbsp;&nbsp;<a href='/'>Home</a></h1></center>"
		return HttpResponse(msg)
	return HttpResponse("<h1 style='color:green;'>No Login received</h1>")




def upload(request):
	data={'static':False, 'invaild':False }
	if request.method=="POST":
		image= request.FILES['image']
		data['name']=image.name
		data['size']=image.size
		if(image.size//1024)>512:
			data['invalid']=True
		else:
			fs=FileSystemStorage()
			fs.save("abc/"+image.name,image)
			data['status']=True
	return render(request,"imageupload.html",data)
from django.db.models import F 
def update(request):
    if request.method=="POST":
    	data=Users.objects.filte(email=request.POST['email'])
    	data.update(phone=request.POST['phone'])
    return render(request,"updatePhone.html")

def success(request):
	if request.session.has_key('user'):
		msg = "<center><h1 style='color:green;padding:200px;'>\
		Congratulations! Your Ticket is Confirmed.<br>Have a nice Journey.</h1></center>"
		return HttpResponse(msg)
	return render(request,'login.html')