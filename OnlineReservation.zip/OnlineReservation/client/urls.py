from django.conf.urls import url,include

from . import views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
     url(r'^$', views.index,name="index"),
     url(r'^upload/', views.upload,name="upload"),
     url(r'^login/', views.login,name="login"),
     url(r'^update/', views.update,name="update"),
     url(r'^doregister/', views.doregister,name="doregister"),
     url(r'^dologin/', views.dologin,name="dologin"),
     url(r'^success/', views.success,name="success"),
     url(r'^logout/', views.logout,name="logout"),

    	]

if settings.DEBUG:
	urlpatterns+=static(settings.MEDIA_URL,document_root =settings.MEDIA_ROOT)